<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "galen", "southhills#", "galen");

$result = $conn->query("SELECT * FROM angular_people");

$outp = "";
while($rs = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
    $outp .= '{"name":"'    . $rs["first_name"] . '",';
    $outp .= '"last_name":"'. $rs["last_name"]        . '",';
    $outp .= '"city":"'     . $rs["city"]     . '"}';
}
$outp ='{"records":['.$outp.']}';
$conn->close();

echo($outp);
?>
